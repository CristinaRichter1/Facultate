package ro.ase.mobil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map.Entry;

public class Joc extends AplicatieMobila implements IFisier,Serializable,Cloneable{
	private static final long serialVersionUID = 1L;
	private float pret;

	public Joc(String nume, long versiune, int guid, float pret) throws IllegalArgumentException {
		super(nume, versiune, guid);
		if (nume == null) throw new IllegalArgumentException("Numele este vid.");
		this.pret = pret;
		
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		try {
			Joc j = new Joc("Gigel",100,40,320.5f);
			Joc j2 = j.clone();
			if (j.equals(j2)) {
				System.out.println("Sunt egale");
			}
			j2.scrieInFisier("fisier.txt");
			j.serializareObiect("serializare.bin",j2);
			j.deserializareObiect("serializare.bin");
			Joc j4 = new Joc("Ionel",300,50,120.5f);
			Joc j5 = new Joc("Cornel",400,30,200.2f);
		
			HashMap<Long,Joc> jocuri = new HashMap<Long,Joc>();
			jocuri.put(Long.valueOf(j.getGuid()), j);
			jocuri.put(Long.valueOf(j2.getGuid()),j2);
			jocuri.put(Long.valueOf(j4.getGuid()),j4);
			jocuri.put(Long.valueOf(j5.getGuid()),j5);
			Thread t = new Thread() {
				public void run() {
					System.out.println("HashMap din Thread: ");
					for (Entry<Long,Joc> entry:jocuri.entrySet()) {
						if(entry.getValue().getNume().startsWith("C"))
							//Afiseaza doar jocul Cornel
							System.out.println(entry.getValue());
					}
					
				}
			};
			t.start();
		} catch (CloneNotSupportedException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	@Override
	public String toString() {
		return this.getNume() + " " + this.getVersiune() + " " + this.getGuid() + " " + this.getPret();
	}

	public float getPret() {
		return pret;
	}

	public void setPret(float pret) {
		this.pret = pret;
	}

	
	public boolean equals(Joc j) {
		if(this.getNume().equals(j.getNume()))
			return true;
		else return false;
	}
	
	public Joc clone() throws CloneNotSupportedException {
		Joc j = (Joc)super.clone();
		return j;
	}
	
	
	@Override
	public String returneazaVersiune() {
		return String.valueOf(this.getVersiune());
	}


	@Override
	public void scrieInFisier(String numeFisier){
		try {
			File f = new File(numeFisier);
			FileWriter fw = new FileWriter(f);
			fw.write(this.getNume()+",");
			fw.write(String.valueOf(this.getVersiune())+",");
			fw.write(String.valueOf(this.getGuid())+",");
			fw.write(String.valueOf(this.getPret()));
			fw.close();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} 
	}
	
	public void serializareObiect(String numeFisier, Joc j) {
		try {
			FileOutputStream fileOut = new FileOutputStream(numeFisier);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(j.getNume());
			out.writeLong(j.getVersiune());
			out.writeInt(j.getGuid());
			out.writeFloat(j.getPret());
			out.flush();
			out.close();
			fileOut.close();
		} catch (IOException i) {
			System.out.println(i.getMessage());
		}
	}
	
	public void deserializareObiect(String numeFisier) {
		try {
			FileInputStream fileIn = new FileInputStream(numeFisier);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			String s = (String) in.readObject();
			long v = (long) in.readLong();
			int i = (int) in.readInt();
			float p = (float) in.readFloat();
			Joc j = new Joc(s,v,i,p);
			System.out.println("Din deserializare: ");
			System.out.println(j);
			in.close();
			fileIn.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException i) {
			i.printStackTrace();
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
