package ro.ase.mobil;

public abstract class AplicatieMobila{
	private String nume;
	private long versiune;
	private final int guid;
	
	public AplicatieMobila(String nume,long versiune,int guid) {
		this.nume = nume;
		this.versiune = versiune;
		this.guid = guid;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public long getVersiune() {
		return versiune;
	}

	public void setVersiune(long versiune) {
		this.versiune = versiune;
	}

	public int getGuid() {
		return guid;
	}
	
	public abstract String returneazaVersiune();

}
