package ro.ase.mobil;

public interface IFisier {
	public void scrieInFisier(String numeFisier);
}
