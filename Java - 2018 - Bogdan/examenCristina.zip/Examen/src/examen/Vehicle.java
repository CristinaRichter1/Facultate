package examen;

public interface Vehicle {
     public String getDetails();
}
