﻿namespace HR
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbIdDepartament = new System.Windows.Forms.TextBox();
            this.tbSalariu = new System.Windows.Forms.TextBox();
            this.lblSalariu = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.tbNume = new System.Windows.Forms.TextBox();
            this.lblNume = new System.Windows.Forms.Label();
            this.lblIdDepartamen = new System.Windows.Forms.Label();
            this.lvAngajati = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.epNume = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epNume)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbIdDepartament);
            this.groupBox1.Controls.Add(this.tbSalariu);
            this.groupBox1.Controls.Add(this.lblSalariu);
            this.groupBox1.Controls.Add(this.btnAdd);
            this.groupBox1.Controls.Add(this.tbNume);
            this.groupBox1.Controls.Add(this.lblNume);
            this.groupBox1.Controls.Add(this.lblIdDepartamen);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1025, 206);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Angajat";
            // 
            // tbIdDepartament
            // 
            this.tbIdDepartament.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIdDepartament.Location = new System.Drawing.Point(180, 154);
            this.tbIdDepartament.Name = "tbIdDepartament";
            this.tbIdDepartament.Size = new System.Drawing.Size(324, 34);
            this.tbIdDepartament.TabIndex = 8;
            // 
            // tbSalariu
            // 
            this.tbSalariu.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSalariu.Location = new System.Drawing.Point(180, 92);
            this.tbSalariu.Name = "tbSalariu";
            this.tbSalariu.Size = new System.Drawing.Size(324, 34);
            this.tbSalariu.TabIndex = 7;
            // 
            // lblSalariu
            // 
            this.lblSalariu.AutoSize = true;
            this.lblSalariu.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalariu.Location = new System.Drawing.Point(20, 102);
            this.lblSalariu.Name = "lblSalariu";
            this.lblSalariu.Size = new System.Drawing.Size(59, 24);
            this.lblSalariu.TabIndex = 5;
            this.lblSalariu.Text = "Salariu";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAdd.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(666, 81);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(287, 61);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "Adauga Angajat";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // tbNume
            // 
            this.tbNume.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNume.Location = new System.Drawing.Point(180, 28);
            this.tbNume.Name = "tbNume";
            this.tbNume.Size = new System.Drawing.Size(324, 34);
            this.tbNume.TabIndex = 3;
            this.tbNume.Validating += new System.ComponentModel.CancelEventHandler(this.tbNume_Validating);
            this.tbNume.Validated += new System.EventHandler(this.tbNume_Validated);
            // 
            // lblNume
            // 
            this.lblNume.AutoSize = true;
            this.lblNume.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNume.Location = new System.Drawing.Point(20, 38);
            this.lblNume.Name = "lblNume";
            this.lblNume.Size = new System.Drawing.Size(55, 24);
            this.lblNume.TabIndex = 2;
            this.lblNume.Text = "Nume";
            // 
            // lblIdDepartamen
            // 
            this.lblIdDepartamen.AutoSize = true;
            this.lblIdDepartamen.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdDepartamen.Location = new System.Drawing.Point(20, 164);
            this.lblIdDepartamen.Name = "lblIdDepartamen";
            this.lblIdDepartamen.Size = new System.Drawing.Size(125, 24);
            this.lblIdDepartamen.TabIndex = 0;
            this.lblIdDepartamen.Text = "Id Departament";
            // 
            // lvAngajati
            // 
            this.lvAngajati.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvAngajati.FullRowSelect = true;
            this.lvAngajati.GridLines = true;
            this.lvAngajati.Location = new System.Drawing.Point(10, 239);
            this.lvAngajati.Name = "lvAngajati";
            this.lvAngajati.Size = new System.Drawing.Size(1026, 260);
            this.lvAngajati.TabIndex = 3;
            this.lvAngajati.UseCompatibleStateImageBehavior = false;
            this.lvAngajati.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nume";
            this.columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Salariu";
            this.columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Id Departament";
            this.columnHeader3.Width = 200;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Departament";
            this.columnHeader4.Width = 200;
            // 
            // epNume
            // 
            this.epNume.ContainerControl = this;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1049, 529);
            this.Controls.Add(this.lvAngajati);
            this.Controls.Add(this.groupBox1);
            this.Name = "MainForm";
            this.Text = "WinApp Run";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epNume)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbIdDepartament;
        private System.Windows.Forms.TextBox tbSalariu;
        private System.Windows.Forms.Label lblSalariu;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox tbNume;
        private System.Windows.Forms.Label lblNume;
        private System.Windows.Forms.Label lblIdDepartamen;
        private System.Windows.Forms.ListView lvAngajati;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ErrorProvider epNume;
    }
}

