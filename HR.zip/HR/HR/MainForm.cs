﻿using HR.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR
{
    private List<Angajat> Angajati { get; set; }
    public partial class MainForm : Form
    {
        List<Entities.Angajat> _angajati;

        public MainForm()
        {
            InitializeComponent();
            _angajati = new List<Entities.Angajat>();

            //_participants = new List<Participant>();
            ////harcodam valorile in colectie
            //_races = new List<Race>();
            //_races.Add(new Race(1, "5k"));
            //_races.Add(new Race(1, "10k"));
            //_races.Add(new Race(1, "21k"));
            //_races.Add(new Race(1, "42k"));
        }

        void AfiseazaAngajati()
        {
            lvAngajati.Items.Clear();

            foreach(var angajat in _angajati)
            {
                var lvi = new ListViewItem(angajat.Nume);
                // lvi.SubItems.Add(angajat.Salariu);
                lvAngajati.Items.Add(lvi);
            }
        }

        private void tbNume_Validating(object sender, CancelEventArgs e)
        {
            string nume = ((TextBox) sender).Text.Trim();
            if (tbNume.Text.Trim().Length<1)
            {
                e.Cancel = true;
                epNume.SetError
                    (
                    tbNume,
                    "Adaugati minim 1 caracter!"
                    );
            }
        }

        private void tbNume_Validated(object sender, EventArgs e)
        {
            epNume.Clear();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var Nume = tbNume.Text.Trim();
            //var Salariu = tbSalariu.Text.Trim();
            //var IdDepartament = tbIdDepartament.Text.Trim();
            AfiseazaAngajati();
        }
    }
}
