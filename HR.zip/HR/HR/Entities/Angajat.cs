﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR.Entities
{
    class Angajat
    {
        #region Properties
        public string Nume { get; set; }
        public decimal Salariu { get; set; }
        public int IdDepartament { get; set; }
        #endregion
        
        public Angajat(string nume, decimal salariu, int idDepartament)
        {
            Nume = nume;
            Salariu = salariu;
            IdDepartament = idDepartament;
        }
    }

}
