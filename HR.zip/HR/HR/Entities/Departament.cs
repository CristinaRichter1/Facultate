﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR.Entities
{
    class Departament
    {
        #region Properties
        public int Id;
        public string Nume;
        #endregion

        public Departament (int id, string nume)
        {
            Id = id;
            Nume = nume;
        }

        //@ string literal, pus pentru ca \ este un special character, si folosesc string literal ca sa nu fac escape
        string filePath = @"C:\Users\richt\Desktop\examene rezolvate\PAW - 2018 - Cristina Examen HR\HR\Departamente.txt";

        //how to read from a file
       // List<string> lines = File.ReadAllLines(filePath).ToList();
    }
}
